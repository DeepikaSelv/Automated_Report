# Sample Input Data Formats for Automated Report Generation

This directory contains examples of input data formats that can be used with the Automated Report Generation project. The project supports various file types, including PDF, CSV, Excel, and text files. Below are descriptions of the expected formats for each type of input.

## PDF Files
- Input PDF files should contain structured data, such as tables or forms, that can be extracted for analysis.
- Ensure that the text is selectable; scanned documents may require OCR processing.

## CSV Files
- CSV files should have a header row that defines the column names.
- Each subsequent row should contain data corresponding to the headers.
- Example format:
  ```
  Date, Sales, Profit
  2023-01-01, 1000, 200
  2023-01-02, 1500, 300
  ```

## Excel Files
- Excel files can contain multiple sheets. The first sheet will be processed by default.
- Each sheet should have a header row, similar to CSV files.
- Example format:
  ```
  | Date       | Sales | Profit |
  |------------|-------|--------|
  | 2023-01-01 | 1000  | 200    |
  | 2023-01-02 | 1500  | 300    |
  ```

## Text Files
- Text files should contain data in a structured format, such as key-value pairs or delimited data.
- Example format:
  ```
  Date: 2023-01-01
  Sales: 1000
  Profit: 200

  Date: 2023-01-02
  Sales: 1500
  Profit: 300
  ```

## Usage
To use these input formats, place your files in the appropriate directory and ensure they adhere to the specified formats. The application will automatically process these files for report generation, data merging, cleaning, and analysis.

For further details on how to run the project and input your API key, please refer to the main README file in the project root.