import pytest
from src.export.to_pdf import export_to_pdf
from src.export.to_excel import export_to_excel
from src.export.to_csv import export_to_csv

def test_export_to_pdf():
    # Sample data for testing
    data = {
        'title': 'Test Report',
        'content': 'This is a test report for PDF export.'
    }
    result = export_to_pdf(data)
    assert result is not None
    assert result.endswith('.pdf')

def test_export_to_excel():
    # Sample data for testing
    data = {
        'title': 'Test Report',
        'content': 'This is a test report for Excel export.'
    }
    result = export_to_excel(data)
    assert result is not None
    assert result.endswith('.xlsx')

def test_export_to_csv():
    # Sample data for testing
    data = {
        'title': 'Test Report',
        'content': 'This is a test report for CSV export.'
    }
    result = export_to_csv(data)
    assert result is not None
    assert result.endswith('.csv')