import pytest
from src.preprocessing.cleaner import clean_data
from src.preprocessing.standardizer import standardize_data
from src.preprocessing.merger import merge_data

def test_clean_data():
    raw_data = ["  Sample Data  ", "  Test Data  "]
    expected_cleaned_data = ["Sample Data", "Test Data"]
    cleaned_data = clean_data(raw_data)
    assert cleaned_data == expected_cleaned_data

def test_standardize_data():
    raw_data = ["Sample Data", "test data"]
    expected_standardized_data = ["SAMPLE DATA", "TEST DATA"]
    standardized_data = standardize_data(raw_data)
    assert standardized_data == expected_standardized_data

def test_merge_data():
    data1 = ["Sample Data 1", "Sample Data 2"]
    data2 = ["Sample Data 3", "Sample Data 4"]
    expected_merged_data = ["Sample Data 1", "Sample Data 2", "Sample Data 3", "Sample Data 4"]
    merged_data = merge_data(data1, data2)
    assert merged_data == expected_merged_data