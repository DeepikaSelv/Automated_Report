import pytest
from src.ocr.ocr_engine import OCR
from src.ocr.models.advanced_ocr import AdvancedOCR

@pytest.fixture
def ocr_instance():
    return OCR(model=AdvancedOCR())

def test_ocr_text_extraction(ocr_instance):
    test_image_path = "tests/test_images/sample_image.png"  # Replace with a valid test image path
    extracted_text = ocr_instance.extract_text(test_image_path)
    assert extracted_text is not None
    assert isinstance(extracted_text, str)
    assert len(extracted_text) > 0

def test_ocr_invalid_input(ocr_instance):
    invalid_image_path = "tests/test_images/invalid_image.png"  # Replace with an invalid test image path
    with pytest.raises(FileNotFoundError):
        ocr_instance.extract_text(invalid_image_path)