import pytest
from src.ingestion.pdf_ingest import ingest_pdf
from src.ingestion.csv_ingest import ingest_csv
from src.ingestion.excel_ingest import ingest_excel
from src.ingestion.text_ingest import ingest_text

def test_ingest_pdf():
    # Test PDF ingestion functionality
    pdf_file_path = 'tests/test_files/sample.pdf'
    data = ingest_pdf(pdf_file_path)
    assert data is not None
    assert isinstance(data, dict)  # Assuming the output is a dictionary

def test_ingest_csv():
    # Test CSV ingestion functionality
    csv_file_path = 'tests/test_files/sample.csv'
    data = ingest_csv(csv_file_path)
    assert data is not None
    assert isinstance(data, dict)  # Assuming the output is a dictionary

def test_ingest_excel():
    # Test Excel ingestion functionality
    excel_file_path = 'tests/test_files/sample.xlsx'
    data = ingest_excel(excel_file_path)
    assert data is not None
    assert isinstance(data, dict)  # Assuming the output is a dictionary

def test_ingest_text():
    # Test text ingestion functionality
    text_file_path = 'tests/test_files/sample.txt'
    data = ingest_text(text_file_path)
    assert data is not None
    assert isinstance(data, str)  # Assuming the output is a string