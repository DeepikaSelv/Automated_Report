import pytest
from src.analysis.kpis import compute_kpis
from src.analysis.insights import generate_insights
from src.analysis.summarizer import generate_summary

def test_compute_kpis():
    sample_data = {
        'revenue': [100, 200, 300],
        'cost': [50, 100, 150]
    }
    expected_kpis = {
        'profit': 300,
        'profit_margin': 0.5
    }
    kpis = compute_kpis(sample_data)
    assert kpis['profit'] == expected_kpis['profit']
    assert kpis['profit_margin'] == expected_kpis['profit_margin']

def test_generate_insights():
    sample_data = {
        'sales': [100, 200, 300],
        'returns': [10, 20, 30]
    }
    insights = generate_insights(sample_data)
    assert 'sales_growth' in insights
    assert insights['sales_growth'] > 0

def test_generate_summary():
    sample_analysis_results = {
        'kpis': {
            'profit': 300,
            'profit_margin': 0.5
        },
        'insights': {
            'sales_growth': 0.2
        }
    }
    summary = generate_summary(sample_analysis_results)
    assert 'Executive Summary' in summary
    assert 'Profit' in summary
    assert 'Sales Growth' in summary