# Architecture of the Automated Report Generation Project

## Overview
The Automated Report Generation project is designed to streamline the process of generating reports from various data sources, including PDF, CSV, Excel, and text files. The application leverages advanced technologies such as Optical Character Recognition (OCR) and Large Language Models (LLMs) to provide insights and generate visual representations of data.

## Components

### 1. Ingestion
The ingestion module is responsible for extracting data from different file formats:
- **PDF Ingestion**: `src/ingestion/pdf_ingest.py`
- **CSV Ingestion**: `src/ingestion/csv_ingest.py`
- **Excel Ingestion**: `src/ingestion/excel_ingest.py`
- **Text Ingestion**: `src/ingestion/text_ingest.py`

### 2. OCR
The OCR module extracts text from images and PDFs:
- **OCR Engine**: `src/ocr/ocr_engine.py`
- **Advanced OCR Model**: `src/ocr/models/advanced_ocr.py`
- **OCR Pipeline**: `src/ocr/pipeline.py`

### 3. Preprocessing
This module cleans, standardizes, and merges the ingested data:
- **Data Cleaner**: `src/preprocessing/cleaner.py`
- **Data Standardizer**: `src/preprocessing/standardizer.py`
- **Data Merger**: `src/preprocessing/merger.py`

### 4. Analysis
The analysis module computes KPIs and generates insights:
- **KPI Computation**: `src/analysis/kpis.py`
- **Insights Generation**: `src/analysis/insights.py`
- **Executive Summary**: `src/analysis/summarizer.py`

### 5. Charts
This module automatically generates charts based on the processed data:
- **Chart Generator**: `src/charts/generator.py`
- **Chart Configuration**: `src/charts/templates/default_chart_config.yaml`

### 6. Export
The export module handles the generation of reports in various formats:
- **Export to PDF**: `src/export/to_pdf.py`
- **Export to Excel**: `src/export/to_excel.py`
- **Export to CSV**: `src/export/to_csv.py`

### 7. User Interface
The user interface is built using Streamlit, allowing users to interact with the application:
- **Streamlit App**: `src/ui/streamlit_app.py`

### 8. API
An API server is implemented to handle requests for report generation and data processing:
- **API Server**: `src/api/server.py`

### 9. Utilities
Utility functions for authentication, input/output operations, and data storage:
- **Authentication**: `src/utils/auth.py`
- **I/O Helpers**: `src/utils/io_helpers.py`
- **Storage Management**: `src/utils/storage.py`

## Running the Project
To run the project, follow these instructions:

1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Create a virtual environment and activate it.
4. Install the required dependencies using `pip install -r requirements.txt`.
5. Copy `.env.example` to `.env` and input your API key in the appropriate location.
6. To run the Streamlit UI, execute `bash scripts/run_streamlit.sh`.
7. To run the API server, execute `bash scripts/run_api.sh`.

Make sure to have the necessary permissions and configurations set up for the API key in the `src/config.py` file.