from ocr_engine import OCRModel
from ingestion.pdf_ingest import ingest_pdf
from ingestion.csv_ingest import ingest_csv
from ingestion.excel_ingest import ingest_excel
from ingestion.text_ingest import ingest_text

class OCRPipeline:
    def __init__(self, api_key):
        self.api_key = api_key
        self.ocr_model = OCRModel(api_key)

    def process_file(self, file_path):
        file_type = self._get_file_type(file_path)
        if file_type == 'pdf':
            data = ingest_pdf(file_path)
        elif file_type == 'csv':
            data = ingest_csv(file_path)
        elif file_type == 'excel':
            data = ingest_excel(file_path)
        elif file_type == 'text':
            data = ingest_text(file_path)
        else:
            raise ValueError("Unsupported file type")

        extracted_text = self.ocr_model.extract_text(data)
        return extracted_text

    def _get_file_type(self, file_path):
        return file_path.split('.')[-1].lower()  # Simple file type detection

    def run(self, file_path):
        extracted_data = self.process_file(file_path)
        return extracted_data