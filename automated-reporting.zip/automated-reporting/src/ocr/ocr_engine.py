from typing import List
import pytesseract
from PIL import Image
import pdf2image
import os

class OCRProcessor:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def extract_text_from_image(self, image_path: str) -> str:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text

    def extract_text_from_pdf(self, pdf_path: str) -> str:
        images = pdf2image.convert_from_path(pdf_path)
        text = ""
        for image in images:
            text += pytesseract.image_to_string(image)
        return text

    def process_files(self, file_paths: List[str]) -> dict:
        extracted_text = {}
        for file_path in file_paths:
            if file_path.lower().endswith(('.png', '.jpg', '.jpeg')):
                extracted_text[file_path] = self.extract_text_from_image(file_path)
            elif file_path.lower().endswith('.pdf'):
                extracted_text[file_path] = self.extract_text_from_pdf(file_path)
            else:
                extracted_text[file_path] = "Unsupported file type"
        return extracted_text

    def save_extracted_text(self, extracted_text: dict, output_dir: str):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        for file_name, text in extracted_text.items():
            base_name = os.path.basename(file_name)
            output_file = os.path.join(output_dir, f"{base_name}_extracted.txt")
            with open(output_file, 'w') as f:
                f.write(text)