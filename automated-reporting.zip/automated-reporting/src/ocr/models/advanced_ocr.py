from typing import Any, Dict
import pytesseract
from PIL import Image
import cv2

class AdvancedOCR:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.tesseract_cmd = self.config.get("tesseract_cmd", "tesseract")

    def preprocess_image(self, image_path: str) -> Any:
        image = cv2.imread(image_path)
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, thresh_image = cv2.threshold(gray_image, 150, 255, cv2.THRESH_BINARY_INV)
        return thresh_image

    def extract_text(self, image_path: str) -> str:
        processed_image = self.preprocess_image(image_path)
        pytesseract.pytesseract.tesseract_cmd = self.tesseract_cmd
        extracted_text = pytesseract.image_to_string(processed_image)
        return extracted_text

    def extract_text_from_pdf(self, pdf_path: str) -> str:
        # Placeholder for PDF extraction logic
        # This can be implemented using pdf2image or similar libraries
        pass

    def run_ocr(self, input_path: str, is_pdf: bool = False) -> str:
        if is_pdf:
            return self.extract_text_from_pdf(input_path)
        else:
            return self.extract_text(input_path)