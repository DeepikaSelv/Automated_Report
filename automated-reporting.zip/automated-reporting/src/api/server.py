from flask import Flask, request, jsonify
import os
from src.utils.auth import verify_api_key
from src.ingestion import pdf_ingest, csv_ingest, excel_ingest, text_ingest
from src.preprocessing import cleaner, standardizer, merger
from src.analysis import kpis, insights, summarizer
from src.charts import generator
from src.export import to_pdf, to_excel, to_csv

app = Flask(__name__)

@app.route('/generate_report', methods=['POST'])
def generate_report():
    api_key = request.headers.get('Authorization')
    if not verify_api_key(api_key):
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.json
    file_type = data.get('file_type')
    file_path = data.get('file_path')

    if file_type == 'pdf':
        data = pdf_ingest.ingest(file_path)
    elif file_type == 'csv':
        data = csv_ingest.ingest(file_path)
    elif file_type == 'excel':
        data = excel_ingest.ingest(file_path)
    elif file_type == 'text':
        data = text_ingest.ingest(file_path)
    else:
        return jsonify({'error': 'Unsupported file type'}), 400

    cleaned_data = cleaner.clean(data)
    standardized_data = standardizer.standardize(cleaned_data)
    merged_data = merger.merge(standardized_data)

    kpi_results = kpis.compute(merged_data)
    insights_results = insights.generate(merged_data)
    summary = summarizer.summarize(insights_results)

    charts = generator.generate_charts(merged_data)

    report = {
        'kpis': kpi_results,
        'insights': insights_results,
        'summary': summary,
        'charts': charts
    }

    return jsonify(report)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))