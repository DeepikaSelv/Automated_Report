# Configuration settings for the Automated Report Generation project

import os

# Load environment variables from .env file
from dotenv import load_dotenv

load_dotenv()

# API Key for LLM insights
API_KEY = os.getenv("API_KEY")

# Other configuration settings
DATA_DIR = os.getenv("DATA_DIR", "data/")
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "output/")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# Add any additional configuration settings as needed
