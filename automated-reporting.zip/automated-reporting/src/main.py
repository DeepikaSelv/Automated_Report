from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os
from src.utils.auth import get_api_key
from src.ingestion import pdf_ingest, csv_ingest, excel_ingest, text_ingest
from src.preprocessing import cleaner, standardizer, merger
from src.analysis import kpis, insights, summarizer
from src.charts import generator
from src.export import to_pdf, to_excel, to_csv

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Automated Report Generation API"}

@app.post("/ingest/pdf")
def ingest_pdf(file: bytes):
    return pdf_ingest.process_pdf(file)

@app.post("/ingest/csv")
def ingest_csv(file: bytes):
    return csv_ingest.process_csv(file)

@app.post("/ingest/excel")
def ingest_excel(file: bytes):
    return excel_ingest.process_excel(file)

@app.post("/ingest/text")
def ingest_text(file: bytes):
    return text_ingest.process_text(file)

@app.post("/preprocess/clean")
def clean_data(data):
    return cleaner.clean(data)

@app.post("/preprocess/standardize")
def standardize_data(data):
    return standardizer.standardize(data)

@app.post("/preprocess/merge")
def merge_data(datasets):
    return merger.merge(datasets)

@app.post("/analysis/kpis")
def compute_kpis(data):
    return kpis.compute(data)

@app.post("/analysis/insights")
def generate_insights(data):
    return insights.generate(data)

@app.post("/analysis/summarize")
def generate_summary(data):
    return summarizer.summarize(data)

@app.post("/charts/generate")
def generate_chart(data):
    return generator.generate(data)

@app.post("/export/pdf")
def export_to_pdf(data):
    return to_pdf.export(data)

@app.post("/export/excel")
def export_to_excel(data):
    return to_excel.export(data)

@app.post("/export/csv")
def export_to_csv(data):
    return to_csv.export(data)

if __name__ == "__main__":
    api_key = get_api_key()
    if not api_key:
        raise ValueError("API key is not set. Please set it in the config.")
    uvicorn.run(app, host="0.0.0.0", port=8000)