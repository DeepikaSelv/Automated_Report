from dotenv import load_dotenv
import os

def get_api_key():
    load_dotenv()  # Load environment variables from .env file
    api_key = os.getenv("API_KEY")  # Retrieve the API key from environment variables
    if not api_key:
        raise ValueError("API key not found. Please set the API_KEY in the .env file.")
    return api_key

def validate_api_key(api_key):
    # Placeholder for API key validation logic
    if len(api_key) < 10:  # Example validation check
        raise ValueError("Invalid API key. Please check your API key.")
    return True