from pathlib import Path
import json

class Storage:
    def __init__(self, storage_path='data/storage.json'):
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.data = self.load_data()

    def load_data(self):
        if self.storage_path.exists():
            with open(self.storage_path, 'r') as file:
                return json.load(file)
        return {}

    def save_data(self):
        with open(self.storage_path, 'w') as file:
            json.dump(self.data, file, indent=4)

    def get(self, key):
        return self.data.get(key)

    def set(self, key, value):
        self.data[key] = value
        self.save_data()

    def delete(self, key):
        if key in self.data:
            del self.data[key]
            self.save_data()