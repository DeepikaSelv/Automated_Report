def read_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def write_file(file_path, data):
    with open(file_path, 'w') as file:
        file.write(data)

def append_to_file(file_path, data):
    with open(file_path, 'a') as file:
        file.write(data)

def delete_file(file_path):
    import os
    if os.path.exists(file_path):
        os.remove(file_path)

def list_files(directory):
    import os
    return os.listdir(directory)

def read_csv(file_path):
    import pandas as pd
    return pd.read_csv(file_path)

def write_csv(file_path, data):
    import pandas as pd
    data.to_csv(file_path, index=False)

def read_excel(file_path):
    import pandas as pd
    return pd.read_excel(file_path)

def write_excel(file_path, data):
    import pandas as pd
    data.to_excel(file_path, index=False)

def read_pdf(file_path):
    from PyPDF2 import PdfReader
    reader = PdfReader(file_path)
    text = ''
    for page in reader.pages:
        text += page.extract_text()
    return text

def save_text(file_path, text):
    with open(file_path, 'w') as file:
        file.write(text)