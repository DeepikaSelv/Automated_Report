import streamlit as st
import pandas as pd
from src.utils.auth import get_api_key
from src.ingestion import pdf_ingest, csv_ingest, excel_ingest, text_ingest
from src.preprocessing import cleaner, standardizer, merger
from src.analysis import kpis, insights, summarizer
from src.charts.generator import generate_charts
from src.export import to_pdf, to_excel, to_csv

def main():
    st.title("Automated Report Generation")
    
    api_key = get_api_key()
    if not api_key:
        st.error("API key is missing. Please set it in the .env file.")
        return

    st.sidebar.header("Upload Data")
    uploaded_file = st.sidebar.file_uploader("Choose a file", type=["pdf", "csv", "xlsx", "txt"])
    
    if uploaded_file is not None:
        file_type = uploaded_file.type
        if file_type == "application/pdf":
            data = pdf_ingest.ingest(uploaded_file)
        elif file_type == "text/csv":
            data = csv_ingest.ingest(uploaded_file)
        elif file_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            data = excel_ingest.ingest(uploaded_file)
        elif file_type == "text/plain":
            data = text_ingest.ingest(uploaded_file)
        else:
            st.error("Unsupported file type.")
            return
        
        st.subheader("Data Preview")
        st.write(data.head())

        cleaned_data = cleaner.clean(data)
        standardized_data = standardizer.standardize(cleaned_data)
        merged_data = merger.merge(standardized_data)

        st.subheader("Key Performance Indicators")
        kpi_results = kpis.compute(merged_data)
        st.write(kpi_results)

        st.subheader("Insights")
        insights_results = insights.generate(merged_data, api_key)
        st.write(insights_results)

        st.subheader("Executive Summary")
        summary = summarizer.generate(merged_data)
        st.write(summary)

        st.subheader("Generate Charts")
        charts = generate_charts(merged_data)
        for chart in charts:
            st.pyplot(chart)

        st.subheader("Export Report")
        export_format = st.selectbox("Select export format", ["PDF", "Excel", "CSV"])
        if st.button("Export"):
            if export_format == "PDF":
                to_pdf.export(merged_data)
            elif export_format == "Excel":
                to_excel.export(merged_data)
            elif export_format == "CSV":
                to_csv.export(merged_data)
            st.success(f"Report exported as {export_format}.")

if __name__ == "__main__":
    main()