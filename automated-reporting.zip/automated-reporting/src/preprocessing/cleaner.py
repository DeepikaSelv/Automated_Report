def clean_data(data):
    """
    Cleans the input data by removing null values, duplicates, and irrelevant columns.
    
    Parameters:
    data (DataFrame): The input data to be cleaned.
    
    Returns:
    DataFrame: The cleaned data.
    """
    # Remove null values
    data = data.dropna()
    
    # Remove duplicates
    data = data.drop_duplicates()
    
    # Assuming 'irrelevant_column' is a placeholder for actual irrelevant columns
    if 'irrelevant_column' in data.columns:
        data = data.drop(columns=['irrelevant_column'])
    
    return data

def remove_outliers(data, column):
    """
    Removes outliers from the specified column in the data using the IQR method.
    
    Parameters:
    data (DataFrame): The input data.
    column (str): The column from which to remove outliers.
    
    Returns:
    DataFrame: The data with outliers removed.
    """
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    return data[(data[column] >= lower_bound) & (data[column] <= upper_bound)]

def standardize_column(data, column):
    """
    Standardizes the specified column in the data to have a mean of 0 and a standard deviation of 1.
    
    Parameters:
    data (DataFrame): The input data.
    column (str): The column to standardize.
    
    Returns:
    DataFrame: The data with the specified column standardized.
    """
    mean = data[column].mean()
    std_dev = data[column].std()
    
    data[column] = (data[column] - mean) / std_dev
    return data

def preprocess_data(data):
    """
    Preprocesses the input data by cleaning and standardizing it.
    
    Parameters:
    data (DataFrame): The input data to be preprocessed.
    
    Returns:
    DataFrame: The preprocessed data.
    """
    data = clean_data(data)
    for column in data.select_dtypes(include=['float64', 'int64']).columns:
        data = standardize_column(data, column)
    
    return data