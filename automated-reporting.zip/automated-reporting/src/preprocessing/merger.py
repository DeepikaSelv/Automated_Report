def merge_datasets(datasets):
    """
    Merges multiple datasets into a single dataset.
    
    Parameters:
        datasets (list): A list of pandas DataFrames to be merged.
        
    Returns:
        pd.DataFrame: A single DataFrame containing the merged data.
    """
    import pandas as pd
    
    if not datasets:
        raise ValueError("No datasets provided for merging.")
    
    merged_data = pd.concat(datasets, ignore_index=True)
    return merged_data


def merge_and_clean(datasets):
    """
    Merges multiple datasets and cleans the resulting dataset.
    
    Parameters:
        datasets (list): A list of pandas DataFrames to be merged.
        
    Returns:
        pd.DataFrame: A cleaned DataFrame containing the merged data.
    """
    from .cleaner import clean_data
    
    merged_data = merge_datasets(datasets)
    cleaned_data = clean_data(merged_data)
    return cleaned_data