import pandas as pd

def ingest_excel(file_path):
    """
    Ingest data from an Excel file and return it as a DataFrame.
    
    Parameters:
    - file_path: str, path to the Excel file to be ingested.
    
    Returns:
    - DataFrame containing the ingested data.
    """
    try:
        # Read the Excel file
        data = pd.read_excel(file_path, sheet_name=None)
        
        # Combine all sheets into a single DataFrame
        combined_data = pd.concat(data.values(), ignore_index=True)
        
        return combined_data
    except Exception as e:
        print(f"Error ingesting Excel file: {e}")
        return None