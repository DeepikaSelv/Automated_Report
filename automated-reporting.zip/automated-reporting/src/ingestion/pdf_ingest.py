from PyPDF2 import PdfReader
import pandas as pd
import os

def ingest_pdf(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist.")
    
    # Read the PDF file
    pdf_reader = PdfReader(file_path)
    text = ""
    
    for page in pdf_reader.pages:
        text += page.extract_text() + "\n"
    
    return text

def pdf_to_dataframe(file_path):
    text = ingest_pdf(file_path)
    # Assuming the text is structured in a way that can be converted to a DataFrame
    data = [line.split() for line in text.splitlines() if line]
    df = pd.DataFrame(data)
    return df

def save_pdf_data_to_csv(pdf_file_path, csv_file_path):
    df = pdf_to_dataframe(pdf_file_path)
    df.to_csv(csv_file_path, index=False)

def save_pdf_data_to_excel(pdf_file_path, excel_file_path):
    df = pdf_to_dataframe(pdf_file_path)
    df.to_excel(excel_file_path, index=False)