from typing import List, Dict
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import yaml

def load_chart_config(config_path: str) -> Dict:
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return config

def generate_bar_chart(data: pd.DataFrame, x: str, y: str, config: Dict) -> plt.Figure:
    plt.figure(figsize=config['figure_size'])
    sns.barplot(data=data, x=x, y=y, palette=config['palette'])
    plt.title(config['title'])
    plt.xlabel(config['x_label'])
    plt.ylabel(config['y_label'])
    plt.xticks(rotation=config['x_tick_rotation'])
    plt.tight_layout()
    return plt

def generate_line_chart(data: pd.DataFrame, x: str, y: str, config: Dict) -> plt.Figure:
    plt.figure(figsize=config['figure_size'])
    sns.lineplot(data=data, x=x, y=y, marker=config['marker'])
    plt.title(config['title'])
    plt.xlabel(config['x_label'])
    plt.ylabel(config['y_label'])
    plt.xticks(rotation=config['x_tick_rotation'])
    plt.tight_layout()
    return plt

def generate_pie_chart(data: pd.Series, config: Dict) -> plt.Figure:
    plt.figure(figsize=config['figure_size'])
    plt.pie(data, labels=data.index, autopct=config['autopct'], startangle=config['startangle'])
    plt.title(config['title'])
    plt.axis('equal')
    return plt

def save_chart(figure: plt.Figure, filename: str) -> None:
    figure.savefig(filename)
    plt.close(figure)

def generate_charts(data: pd.DataFrame, chart_type: str, config_path: str, output_path: str) -> None:
    config = load_chart_config(config_path)
    
    if chart_type == 'bar':
        figure = generate_bar_chart(data, config['x'], config['y'], config)
    elif chart_type == 'line':
        figure = generate_line_chart(data, config['x'], config['y'], config)
    elif chart_type == 'pie':
        figure = generate_pie_chart(data[config['pie_data']], config)
    else:
        raise ValueError("Unsupported chart type: {}".format(chart_type))
    
    save_chart(figure, output_path)