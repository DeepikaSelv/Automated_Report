def export_to_excel(data, file_path):
    import pandas as pd

    # Convert data to a DataFrame
    df = pd.DataFrame(data)

    # Export to Excel
    df.to_excel(file_path, index=False)

    return f"Report successfully exported to {file_path}"