from fpdf import FPDF

class PDFReport:
    def __init__(self, title, author):
        self.pdf = FPDF()
        self.title = title
        self.author = author
        self.pdf.set_auto_page_break(auto=True, margin=15)
        self.pdf.add_page()
        self.pdf.set_font("Arial", 'B', 16)
        self.pdf.cell(0, 10, self.title, ln=True, align='C')
        self.pdf.set_font("Arial", 'I', 12)
        self.pdf.cell(0, 10, f'By {self.author}', ln=True, align='C')
        self.pdf.ln(10)

    def add_section(self, title, content):
        self.pdf.set_font("Arial", 'B', 14)
        self.pdf.cell(0, 10, title, ln=True)
        self.pdf.set_font("Arial", '', 12)
        self.pdf.multi_cell(0, 10, content)
        self.pdf.ln(5)

    def save(self, filename):
        self.pdf.output(filename)

def export_report_to_pdf(report_data, filename, title="Automated Report", author="Automated System"):
    pdf_report = PDFReport(title, author)
    
    for section_title, section_content in report_data.items():
        pdf_report.add_section(section_title, section_content)
    
    pdf_report.save(filename)