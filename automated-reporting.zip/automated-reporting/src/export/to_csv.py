def export_to_csv(data, file_path):
    import pandas as pd

    # Convert the data to a DataFrame
    df = pd.DataFrame(data)

    # Export the DataFrame to a CSV file
    df.to_csv(file_path, index=False)

    return f"Data exported successfully to {file_path}"