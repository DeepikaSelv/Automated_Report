def compute_kpis(data):
    kpis = {}
    
    # Example KPI calculations
    kpis['total_sales'] = data['sales'].sum()
    kpis['average_order_value'] = data['sales'].mean()
    kpis['total_customers'] = data['customer_id'].nunique()
    
    # Add more KPI calculations as needed
    return kpis

def generate_kpi_report(data):
    kpi_results = compute_kpis(data)
    report = "KPI Report\n"
    report += "====================\n"
    for kpi, value in kpi_results.items():
        report += f"{kpi}: {value}\n"
    return report