from typing import Any, Dict

def generate_executive_summary(data: Dict[str, Any]) -> str:
    """
    Generate an executive summary based on the provided data.

    Parameters:
    - data: A dictionary containing analysis results and insights.

    Returns:
    - A string representing the executive summary.
    """
    summary = "Executive Summary\n"
    summary += "=" * 50 + "\n"
    
    # Example of summarizing key insights
    if 'key_insights' in data:
        summary += "Key Insights:\n"
        for insight in data['key_insights']:
            summary += f"- {insight}\n"
    
    # Example of summarizing KPIs
    if 'kpis' in data:
        summary += "\nKey Performance Indicators (KPIs):\n"
        for kpi, value in data['kpis'].items():
            summary += f"{kpi}: {value}\n"
    
    # Add any other relevant information from the data
    if 'additional_info' in data:
        summary += "\nAdditional Information:\n"
        summary += data['additional_info'] + "\n"
    
    return summary.strip()