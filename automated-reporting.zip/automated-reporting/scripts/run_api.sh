#!/bin/bash

# This script runs the API server for the Automated Report Generation project.

# Load environment variables from .env file
if [ -f .env ]; then
    export $(cat .env | xargs)
fi

# Run the API server
python3 src/api/server.py