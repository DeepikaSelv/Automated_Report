#!/bin/bash

# This script runs the Streamlit application for the Automated Report Generation project.

# Navigate to the src directory
cd ../src

# Run the Streamlit app
streamlit run ui/streamlit_app.py --server.port 8501 --server.address 0.0.0.0